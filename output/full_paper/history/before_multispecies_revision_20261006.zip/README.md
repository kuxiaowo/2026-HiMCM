# 2026 HiMCM 数学建模项目

当前研究对象为埃托沙国家公园。第一题已完成一页LaTeX稿及PDF；第二题已完成条件性资源配置模型、正式论文正文、图表及本地PDF编译；第三题已完成季节服务与人力需求的条件性规划计算及正式中文正文、图表和PDF阅读稿，实际生态成效尚未验证。

## 当前成果入口

- [当前中文白话详解源](docs/paper/full_paper_zh.tex)：原地扩充完整译文，包含六题分步流程、19个编号公式的逐项变量与单位说明、关键行内公式说明，以及完整教学算例。原公式、13表与6图结果保持一致；不再以24页作为讲解稿上限。[讲解源检查](output/full_paper/full_paper_zh_explanation_validation.json)。已按用户指定使用本机TeX Live／XeLaTeX编译为39页，引用、页码、文本范围及全部渲染页面检查通过；[当前详解PDF](output/pdf/full_paper_zh_explained.pdf)。内置编译器仍有独立平台目录错误。
- [历史24页中文全文译文PDF](output/pdf/full_paper_zh.pdf)：对应增加白话解释之前的源，不能当作当前详解PDF；[对应历史源与核验备查](output/full_paper/history/pre_plain_explanation_20261006/)。原译文包含124段叙述、6图13表19式15条参考，曾完成编译与目视核验。
- [完整英文论文](output/pdf/full_paper.pdf)、[单文件LaTeX源](docs/paper/full_paper.tex)：当前21页，包含摘要、目录、1—6题、一页信件、15条参考资料和AI使用说明，满足本轮25页上限。Introduction扩充至约640词，占一页可写高度约93%；一级标题之间连续排版，取消二级标题前的强制分页，并处理页末孤立标题和落款。6图13表19式、模型参数与结果保持。[完整核验](output/full_paper/full_paper_validation.json)、[分页核验](output/full_paper/full_paper_layout_validation.json)。前三节名称与原模板字体字号保持；中文详解保留上一轮内容，本轮只修订英文正式稿。
- [第六题6页正式稿](output/pdf/question6_adaptation.pdf)、[LaTeX源](docs/paper/question6_adaptation.tex)：真实空间数据与条件试算；奇特旺边界一致性限制保留。

- [第一题一页PDF](output/pdf/question1_protection_definition.pdf)、[LaTeX源文件](docs/paper/question1_protection_definition.tex)：12磅正文，三个小节、一张表和两组公式；[编译核验](output/question1/q1_latex_compile_verification.json)。

- [第二题正式PDF](output/pdf/question2_framework.pdf)：8页，20个编号公式、2幅图和4张表；开头含术语说明。
- [LaTeX源文件](docs/paper/question2_framework.tex)、[Markdown同步正文](docs/paper/question2_resource_allocation.md)、[第二题结构索引](docs/paper/question2_framework.md)。
- [模型结果](output/question2/q2_results.json)、[模型输入](output/question2/q2_model_inputs.json)、[独立模型核验](output/question2/q2_verification.json)。
- [PDF编译与版式核验](output/question2/q2_latex_compile_verification.json)、[章节核验](output/question2/q2_chapter_validation.json)。
- [整体建模计划](docs/整体建模计划.md)、[计算说明](docs/modeling_notes/question2_calculation_notes.md)、[项目状态与上传说明](docs/项目状态与上传说明.md)。
- [第一题详细方法底稿](docs/paper/question1_protection_definition.md)、[第三题精简方案](docs/第三题精简方案.md)。

- [第三题实算](docs/第三题模型实算.md)、[第三题框架](docs/paper/question3_framework.md)、[月度结果](output/question3/q3_monthly.csv)、[独立核验](output/question3/q3_independent_verification.json)。
- [第三题正式正文](docs/paper/question3_seasonal_staffing.md)、[LaTeX源](docs/paper/question3_framework.tex)、[PDF阅读稿](output/pdf/question3_framework.pdf)：6页，5节、13个三级标题、12个编号公式、2幅图、3张表；本机XeLaTeX成功编译，内置编译器的平台错误单独记录。
- [第三题章节与版式核验](output/question3/q3_chapter_validation.json)、[原创图件设计说明](docs/modeling_notes/q3_figure_design_references.md)。
- [第三题环境](environment-question3.yml)：有效工时固定120小时，中档年峰值57人、异常干旱压力峰值62人，均依赖明确的服务假设。

**第二题当前基准：**人员可用比例60%、无人机30架；有效工时仍为120小时，频次仍为每100km²每月8点次，响应期限仍为2小时。预算21240人时、1200机时。第三题已同步177人参考、1200机时并重算；常规峰值57人、干旱运维情景62人。第四题131个案例中127个可行方案独立核验通过。旧第二题已保留历史压缩包。

## 模型范围

第二题优化地面监测人时与无人机机时，结合动物保护责任、可燃生境、道路进入和响应可达性，采用线性规划。第二题排除水源、降雨与SPI；第三题另加入17处历史人工水点运维、季节额外火险筛查及异常干旱运维压力，不计算SPI或无依据的运水量。服务分表示指定协议下的监测服务能力，不能解释为动物存活率、实际减损或完整生态认证。

## 复现与编译

计算优先使用conda环境；依赖入口为[道路环境](environment-roads.yml)、[分区环境](environment-regions.yml)。本项目现有环境路径为`D:/Python/Conda/envs/himcn-roads/python.exe`。在项目根目录执行：

```powershell
& 'D:/Python/Conda/envs/himcn-roads/python.exe' -X utf8 scripts/modeling/build_question2.py
& 'D:/Python/Conda/envs/himcn-roads/python.exe' -X utf8 scripts/modeling/write_question2_report.py
```

PDF已使用本机TeX Live 2026 / XeLaTeX编译并逐页核验。修改源文件后需重新编译两遍，以更新交叉引用；具体命令见[计算说明](docs/modeling_notes/question2_calculation_notes.md)。运行环境路径可按本机调整，项目成果和中间文件保存在本项目内。

## 仓库文件范围

仓库保留文档、脚本、当前模型所需的项目数据、图表、求解结果、最终PDF及历史备查成果。约2.2GB的旧GPCC全球降水原始压缩包不参与当前模型，继续保留本地而不入库；新增临时缓存、Python字节码和LaTeX中间文件也不入库。忽略规则不删除本地文件。

`.gitattributes`保留LaTeX源及关键模型JSON的原始字节，防止Git换行转换改变已有SHA-256核验指纹。第二题输入与结果已按本轮两项参数更新；原始资料保持不变，旧结果归档备查。

开发提交使用`developing`分支，通过PR合并到`main`。项目规则见[AGENTS.md](AGENTS.md)。

完整稿复现：先按当前基准更新并核验Q2—Q4保存结果，运行`build_full_paper_figures.py`与`write_full_paper.py`；用XeLaTeX编译`docs/paper/full_paper.tex`并稳定引用后，运行`validate_full_paper.py`。正式PDF与源文件保持同名稳定路径。

完整稿按用户新提供的论文DOCX调整：Times New Roman正文12pt、一级标题22pt、二级标题16pt、封面题目14pt、编号18pt红色；图表题注Arial10pt、符号表11pt，首段也缩进24pt。版式测量与差异记录见`output/full_paper/template_style_contract.json`。边距采用原题最低要求1.5cm；模板10/11pt局部字号与原题至少12pt要求存在已披露冲突，本稿是按用户指定字号制作的模板版，不能把版式核验通过理解为所有参赛格式要求均满足。
