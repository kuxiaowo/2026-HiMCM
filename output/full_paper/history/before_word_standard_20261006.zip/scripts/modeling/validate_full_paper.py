"""Check final page limits, numbering, provenance and current model values."""
from __future__ import annotations
import hashlib
import json
import re
import subprocess
from pathlib import Path
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parents[2]


def read(name):
    return json.loads((ROOT/name).read_text(encoding='utf-8'))


def main():
    source=ROOT/'docs/paper/full_paper.tex';pdf=ROOT/'output/pdf/full_paper.pdf'
    tex=source.read_text(encoding='utf-8')
    manifest=read('output/full_paper/full_paper_manifest.json')
    extracted=subprocess.run(['D:/texlive/2026/bin/windows/pdftotext.exe','-layout','-enc','UTF-8',str(pdf),'-'],
        capture_output=True,check=True).stdout.decode('utf-8')
    pages=[page for page in extracted.split('\f') if page.strip()]
    assert len(pages)==24
    for i,page in enumerate(pages,1):
        assert re.search(r'Team\s+510105201001220151',page)
        assert re.search(r'Page\s+'+str(i)+r'\s+of\s+24',page)
    assert 'Summary Sheet' in pages[0] and 'Contents' in pages[1]
    assert 'Letter to IMMC' in pages[20] and 'Yours faithfully' in pages[21]
    assert 'References' in pages[22] and 'Report on Use of AI' in pages[23]
    assert not re.search(r'\?\?|\[\?\]|@[A-Z_]+@',extracted)
    assert not re.search(r'[\u4e00-\u9fff]',extracted)
    figures=[int(v) for v in re.findall(r'\bFigure\s+(\d+)\.',extracted)]
    tables=[int(v) for v in re.findall(r'\bTable\s+(\d+)\.',extracted)]
    assert figures==list(range(1,7)),figures
    assert tables==list(range(1,14)),tables
    assert tex.count(r'\begin{equation}')==19
    labels=re.findall(r'\\label\{([^}]+)\}',tex)
    assert len(labels)==len(set(labels))
    refs=re.findall(r'\\(?:eqref|ref)\{([^}]+)\}',tex)
    assert set(refs)-{'LastPage'}<=set(labels)
    bib=re.findall(r'\\bibitem\{([^}]+)\}',tex)
    citations=[k for x in re.findall(r'\\cite\{([^}]+)\}',tex) for k in x.split(',')]
    assert set(citations)<=set(bib) and len(bib)==14
    stack=[]
    for action,env in re.findall(r'\\(begin|end)\{([^}]+)\}',tex):
        if action=='begin':stack.append(env)
        else:assert stack and stack.pop()==env
    assert not stack
    log=(ROOT/'output/pdf/full_paper.log').read_text(encoding='utf-8',errors='replace')
    assert not re.search(r'Overfull|Underfull|Missing character|undefined|^!',log,re.M)
    assert '\\documentclass[12pt,a4paper]' in tex and 'margin=2cm' in tex
    assert not re.search(r'\\(?:small|footnotesize|scriptsize|tiny)\b',tex)
    assert manifest['source_sha256']==hashlib.sha256(source.read_bytes()).hexdigest()
    assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==sha for name,sha in manifest['input_sha256'].items())
    q2=read('output/question2/q2_results.json');q3=read('output/question3/q3_results.json')
    q4=read('output/question4/q4_results.json');q6=read('output/question6/q6_results.json')
    peak=max(q3['monthly'],key=lambda v:v['required_person_hours'])
    drought=next(v for v in q3['sensitivity'] if v['scenario']=='base' and v['abnormal_drought'])
    assert q2['optimum']['human_budget']==21240 and q2['optimum']['drone_budget']==1200
    assert q3['fixed_reference_staff']==177 and peak['required_staff']==57 and drought['annual_fixed_staff']==62
    for value in [q2['optimum']['score'],q2['optimum']['total_person_hours'],q2['optimum']['drone_flight_hours'],
                  peak['required_person_hours'],drought['peak_person_hours']]:
        assert f'{value:.2f}' in extracted
    assert '1214.06' in pages[18] and '952.63' in pages[18] and '27.44%' in pages[18]
    assert 'conditional' in pages[19].lower() and 'actual park staffing' in pages[19].lower()
    assert q6['status']=='real_geographic_inputs_with_explicit_service_assumptions'
    assert q4['current_reference_staff']==177 and q4['current_drone_budget']==1200
    standalone={}
    for label,path in [('question3','output/pdf/question3_framework.pdf'),('question6','output/pdf/question6_adaptation.pdf')]:
        info=subprocess.run(['D:/texlive/2026/bin/windows/pdfinfo.exe',str(ROOT/path)],capture_output=True,check=True).stdout
        count=int(re.search(rb'Pages:\s+(\d+)',info).group(1));assert count==6
        standalone[label]={'pages':count,'pdf':path,'sha256':hashlib.sha256((ROOT/path).read_bytes()).hexdigest()}
    info=subprocess.run(['D:/texlive/2026/bin/windows/pdffonts.exe',str(pdf)],capture_output=True,check=True).stdout.decode('ascii',errors='replace')
    fontlines=[line for line in info.splitlines()[2:] if line.strip()]
    assert all(re.search(r'\byes\s+yes\s+(?:yes|no)\s+\d+',line) for line in fontlines)
    head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
    assert head=='57da67ca6e546696ad5dfeeb5150c5443d18bd95'
    assert subprocess.check_output(['git','branch','--show-current']).decode().strip()=='developing'
    assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U']).strip()
    report={'status':'passed','verified_at_utc':datetime.now(timezone.utc).isoformat(),'team_control_number':'510105201001220151',
      'language':'English','total_pdf_pages':24,'count_includes_summary_contents_letter_references_AI':True,
      'letter_pages':[21,22],'body_font_points':12,'margin_cm':2,'figure_numbers':figures,'table_numbers':tables,
      'numbered_equations':19,'bibliography_entries':14,'all_page_headers_numbered':True,'cross_references_resolved':True,
      'environment_pairing_passed':True,'current_model_numbers_checked':True,'input_fingerprints_match':True,
      'all_fonts_embedded':True,'embedded_font_count':len(fontlines),'latex_errors':0,'overflow_warnings':0,
      'underfull_warnings':0,'visual_review':{'pages':list(range(1,25)),'status':'passed',
        'method':'all 24 pages inspected by two reviewers; revised summary inspected again after adding its page header'},
      'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),
      'standalone_chapters':standalone,'remote_commit_integrated':head,'working_branch':'developing',
      'builtin_compiler':'unavailable: Unable to find standard directories for platform; existing XeLaTeX used',
      'limitations_retained':['Chitwan published boundary does not match official area','personnel estimates are conditional pooled workloads','service score is not ecological outcome']}
    (ROOT/'output/full_paper/full_paper_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    manifest.update(status='passed_compilation_and_visual_review',actual_total_pages=24,pdf='output/pdf/full_paper.pdf',
                    pdf_sha256=report['pdf_sha256'],validation='output/full_paper/full_paper_validation.json')
    (ROOT/'output/full_paper/full_paper_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['status','total_pdf_pages','letter_pages','figure_numbers','table_numbers','current_model_numbers_checked']},ensure_ascii=False))


if __name__=='__main__':main()
