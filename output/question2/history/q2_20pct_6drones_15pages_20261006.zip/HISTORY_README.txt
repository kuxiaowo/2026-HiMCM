Historical Q2 baseline: 20% available staff, 6 drones, 120 hours/person-month, 8 checks/100 km2/month, 2-hour response. Superseded by user request on 2026-10-06. Not current manuscript.
